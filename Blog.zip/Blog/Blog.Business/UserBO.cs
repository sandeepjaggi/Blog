﻿using Blog.Data;
using Blog.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blog.Business
{
    /// <summary>
    /// UserBO
    /// </summary>
    public class UserBO
    {
        /// <summary>
        /// UserBO Constructor
        /// </summary>
        public UserBO()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        /// <summary>
        /// checkUserAuthenticate
        /// </summary>
        /// <param name="userDTO"></param>
        /// <returns></returns>
        public bool checkUserAuthenticate(UserDTO userDTO)
        {
            try
            {
                return UserDataAccess.checkUserAuthenticate(userDTO);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// RegisterBlogUser
        /// </summary>
        /// <param name="userDTO"></param>
        /// <returns></returns>
        public int RegisterBlogUser(UserDTO userDTO)
        {
            try
            {
                return UserDataAccess.RegisterBlogUser(userDTO);
            }
            catch
            {
                throw;
            }
        }

        public DataTable GetAllUsers()
        {
            try
            {
                return UserDataAccess.GetAllUsers();
            }
            catch
            {
                throw;
            }
           
        }

        public DataTable GetAllComments()
        {
            try
            {
                return UserDataAccess.GetAllComments();
            }
            catch
            {
                throw;
            }

        }

        /// <summary>
        /// UpdateUser
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="userType"></param>
        public void UpdateUser(int userID, string userType)
        {
            try
            {
                UserDataAccess.UpdateUser(userID, userType);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// UpdateUser
        /// </summary>
        /// <param name="userID"></param>
        public void DeleteUser(int userID)
        {
            try
            {
                UserDataAccess.DeleteUser(userID);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// UpdateComment
        /// </summary>
        /// <param name="CommentID"></param>
        public void Deletecomment(int CommentID)
        {
            try
            {
                UserDataAccess.DeleteComment(CommentID);
            }
            catch
            {
                throw;
            }
        }
    }
}
