﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Blog.DTO;
using Blog.Data;
using System.Data;

namespace Blog.Business
{
    /// <summary>
    /// BlogBO
    /// </summary>
    public class BlogBO
    {
        /// <summary>
        /// BlogBO Constructor
        /// </summary>
        public BlogBO()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        /// <summary>
        /// InsertBlog
        /// </summary>
        /// <param name="blogDTO"></param>
        /// <returns></returns>
        public int InsertUpdateBlog(BlogDTO blogDTO)
        {
            try
            {
                return BlogDataAccess.InsertUpdateBlog(blogDTO);
            }
            catch
            {
                throw;
            }
           
        }

        /// <summary>
        /// GetAllArticles for home page
        /// </summary>
        /// <returns></returns>
        public DataTable GetAllArticles()
        {
            try
            {
                return BlogDataAccess.GetAllArticles();
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// GetAllArticles
        /// </summary>
        /// <returns></returns>
        public DataTable GetAllArticles(string userID)
        {
            try
            {
                return BlogDataAccess.GetAllArticles(userID);
            }
            catch
            {
                throw;
            }
        }

        public DataTable GetSeletectedArticles(int blogid)
        {
            try
            {
                return BlogDataAccess.GetSeletectedArticles(blogid);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// PublishBlog
        /// </summary>
        /// <param name="blogid"></param>
        /// <returns></returns>
        public int PublishBlog(int blogid)
        {
            try
            {
                return BlogDataAccess.PublishBlog(blogid);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// RetriveBlogDetails
        /// </summary>
        /// <param name="bid"></param>
        /// <returns></returns>
        public BlogDTO RetriveBlogDetails(string bid)
        {
            try
            {
                return BlogDataAccess.RetriveBlogDetails(bid);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// DeleteBlog
        /// </summary>
        /// <param name="bid"></param>
        public void DeleteBlog(int bid)
        {
            try
            {
                 BlogDataAccess.DeleteBlog(bid);
            }
            catch
            {
                throw;
            }
        }
    }
}
