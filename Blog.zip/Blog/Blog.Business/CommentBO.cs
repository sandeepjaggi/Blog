﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Blog.DTO;
using Blog.Data;
using System.Data;

namespace Blog.Business
{
    /// <summary>
    /// CommentBO
    /// </summary>
    public class CommentBO
    {
        /// <summary>
        /// 
        /// </summary>
        public CommentBO()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        /// <summary>
        /// InsertCommentBlog
        /// </summary>
        /// <param name="commentDTO"></param>
        /// <returns></returns>
        public int InsertCommentBlog(CommentDTO commentDTO)
        {
            try
            {
                return CommentDataAccess.InsertCommentBlog(commentDTO);
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// GetCommentsByBlogID
        /// </summary>
        /// <param name="blogid"></param>
        /// <returns></returns>
        public DataTable  GetCommentsByBlogID(int blogid)
        {
            try
            {
                return CommentDataAccess.GetCommentsByBlogID(blogid);
            }
            catch
            {
                throw;
            }
        }
    }
}
