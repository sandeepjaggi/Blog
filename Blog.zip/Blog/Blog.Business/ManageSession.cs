﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Security;

namespace Blog.Business
{
    /// <summary>
    /// ManageSession
    /// </summary>
    public class ManageSession
    {
        /// <summary>
        /// ManageSession
        /// </summary>
        public ManageSession()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        /// <summary>
        /// string UserID
        /// </summary>
        public static string UserID
        {
            get
            {
                if (HttpContext.Current.Session["UserID"] != null)
                {
                    return HttpContext.Current.Session["UserID"].ToString();
                }
                else
                {
                    FormsAuthentication.SignOut();
                    return string.Empty;
                }
            }
            set
            {
                HttpContext.Current.Session["UserID"] = value;
            }
        }
        /// <summary>
        /// string UserName
        /// </summary>
        public static string UserName
        {
            get
            {
                if (HttpContext.Current.Session["UserName"] != null)
                {
                    return HttpContext.Current.Session["UserName"].ToString();
                }
                else
                {
                    FormsAuthentication.SignOut();
                    return string.Empty;
                }
            }
            set
            {
                HttpContext.Current.Session["UserName"] = value;
            }
        }


        /// <summary>
        /// string UserType
        /// </summary>
        public static string UserRole
        {
            get
            {
                if (HttpContext.Current.Session["UserRole"] != null)
                {
                    return HttpContext.Current.Session["UserRole"].ToString();
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                HttpContext.Current.Session["UserRole"] = value;
            }
        }


        /// <summary>
        /// string LoginDate
        /// </summary>
        public static string LoginDate
        {
            get
            {
                if (HttpContext.Current.Session["LoginDate"] != null)
                {
                    return HttpContext.Current.Session["LoginDate"].ToString();
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                HttpContext.Current.Session["LoginDate"] = value;
            }
        }


        #region Static Method setSession

        /// <summary>
        /// Method to set session value for a key
        /// </summary>
        /// <param name="sessionKey">Key Name</param>
        /// <param name="sessionValue">Session Value</param>
        public static void setSession(string sessionKey, object sessionValue)
        {
            HttpContext.Current.Session[sessionKey] = sessionValue;
        }

        #endregion Method setSession

        #region Static Method getSession

        /// <summary>
        /// Method to get the session key value from the current session
        /// </summary>
        /// <param name="sessionKey">Key Name</param>
        /// <returns>Object contain the value</returns>
        public static object getSession(string sessionKey)
        {
            object keyValue = null;

            if (!Equals(HttpContext.Current.Session[sessionKey], null))
            {
                keyValue = HttpContext.Current.Session[sessionKey];
            }

            return keyValue;
        }

        #endregion Static Method getSession

        #region Static Method removeAllSessions

        /// <summary>
        /// Abandon all sessions.
        /// </summary>
        public static void removeAllSessions()
        {
            HttpContext.Current.Session.Abandon();
        }

        #endregion Static Method removeAllSessions
    }
}
