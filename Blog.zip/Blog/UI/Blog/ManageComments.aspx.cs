﻿using Blog.Business;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;

namespace Blog
{
    public partial class ManageComments : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                if (ManageSession.UserName.Length > 0 && HttpContext.Current.Session["UserRole"] != null)
                {

                    BindComments();
                }
                else
                {
                    Response.Redirect("~/Account/Login.aspx");
                }
            }
        }

        /// <summary>
        /// BindComments
        /// </summary>
        protected void BindComments()
        {
            UserBO objBO = new UserBO();
            try
            {
                gvComments.DataSource = objBO.GetAllComments();
                gvComments.DataBind();
            }
            catch(Exception ex)
            {
                Response.Write(ex);
            }
            finally
            {
                objBO = null;
            }

        }

        /// <summary>
        /// OnRowDeleting
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void OnRowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int Commentid = Convert.ToInt32(gvComments.DataKeys[e.RowIndex].Values[0]);
            UserBO objBO = new UserBO();
            objBO.Deletecomment(Commentid);
            lblresult.ForeColor = Color.Green;
            lblresult.Text = " Comment deleted successfully";
            this.BindComments();


        }

        /// <summary>
        /// OnRowDataBound
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void OnRowDataBound(object sender, GridViewRowEventArgs e)
        {
            

        }

    }
}