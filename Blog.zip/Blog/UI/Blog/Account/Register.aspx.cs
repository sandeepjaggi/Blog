﻿using System;
using System.Linq;
using System.Web;
using System.Web.UI;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Owin;
using Blog.Models;
using Blog.Business;
using Blog.DTO;

namespace Blog.Account
{
    public partial class Register : Page
    {

        /// <summary>
        /// CreateUser
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void CreateUser_Click(object sender, EventArgs e)
        {
            // get objects declare
            UserBO userBO = new UserBO();
            UserDTO userDTO = new UserDTO();
            if (Page.IsValid)
            {
                int retValue;
                try
                {
                    userDTO.UserName = this.Email.Text;
                    userDTO.Password = this.Password.Text;
                    // Execute For Update
                    retValue = userBO.RegisterBlogUser(userDTO);
                    if (retValue == 1)
                    {

                        this.ErrorMessage.Text = "Blog user has been created successfully.";
                    }
                    else
                    {

                        this.ErrorMessage.Text = "Error: Blog user created fail. Please try again!";
                    }
                }
                catch (Exception ex)
                {
                    this.ErrorMessage.Text = ex.Message.ToString();
                }
                finally
                {
                    userBO = null;
                }
            }
        }
    }
}