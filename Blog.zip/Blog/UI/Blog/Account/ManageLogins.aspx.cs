﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Blog.Business;
using System.Drawing;

namespace Blog.Account
{
    /// <summary>
    /// ManageLogins
    /// </summary>
    public partial class ManageLogins : System.Web.UI.Page
    {

        /// <summary>
        /// Page_Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
           
            if (!Page.IsPostBack)
            {
                if (ManageSession.UserName.Length > 0 && HttpContext.Current.Session["UserRole"] != null)
                {

                    BindUserDetails();
                }
                else
                {
                    Response.Redirect("~/Account/Login.aspx");
                }
            }
        }

     
        /// <summary>
        /// BindUserDetails
        /// </summary>
        protected void BindUserDetails()
        {
            UserBO objBO = new UserBO();
            try
            {                
                gvUsers.DataSource = objBO.GetAllUsers();
                gvUsers.DataBind();
            }
            catch
            {
                // TO DO
            }
            finally
            {
                objBO = null;
            }
           
        }


        /// <summary>
        /// OnRowEditing
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void OnRowEditing(object sender, GridViewEditEventArgs e)
        {       
              
            gvUsers.EditIndex = e.NewEditIndex;
            this.BindUserDetails();
        }

        /// <summary>
        /// OnRowUpdating
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void OnRowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            GridViewRow row = gvUsers.Rows[e.RowIndex];
            int userID = Convert.ToInt32(gvUsers.DataKeys[e.RowIndex].Values[0]);
            string userType = (row.FindControl("ddlUserType") as DropDownList).SelectedItem.Text;
            UserBO objBO = new UserBO();
            objBO.UpdateUser(userID, userType);

            lblresult.ForeColor = Color.Green;
            lblresult.Text = " User updated successfully";
            gvUsers.EditIndex = -1;
            this.BindUserDetails();
        }


        /// <summary>
        /// OnRowCancelingEdit
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void OnRowCancelingEdit(object sender, EventArgs e)
        {
            gvUsers.EditIndex = -1;
            this.BindUserDetails();
        }

        /// <summary>
        /// OnRowDeleting
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void OnRowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int userID = Convert.ToInt32(gvUsers.DataKeys[e.RowIndex].Values[0]);
            UserBO objBO = new UserBO();
            objBO.DeleteUser(userID);
            lblresult.ForeColor = Color.Green;
            lblresult.Text = " User deleted successfully";
            this.BindUserDetails();

           
        }

        /// <summary>
        /// OnRowDataBound
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void OnRowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow && e.Row.RowIndex != gvUsers.EditIndex)
            {
                (e.Row.Cells[2].Controls[2] as LinkButton).Attributes["onclick"] = "return confirm('Do you want to delete this row?');";

                string ddltype = DataBinder.Eval(e.Row.DataItem, "UserType").ToString();
                if (ddltype == "Admin")
                {
                    (e.Row.Cells[2].Controls[2] as LinkButton).Visible = false;
                }
            }
           
        }


    }
}