﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Blog.Account
{
    public partial class Logout : System.Web.UI.Page
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            Session.Abandon();
            Session.RemoveAll();
            HttpContext.Current.Session["UserName"] = null;
            HttpContext.Current.Session["UserRole"]=null;
            FormsAuthentication.SignOut();
            Response.Redirect("~/Account/login.aspx");
        }
    }
}