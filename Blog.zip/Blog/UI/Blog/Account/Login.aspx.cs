﻿using System;
using System.Web;
using System.Web.UI;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Owin;
using Blog.Models;
using System.Web.UI.WebControls;
using Blog.Business;
using Blog.DTO;
using System.Web.Security;

namespace Blog.Account
{
    public partial class Login : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            RegisterHyperLink.NavigateUrl = "Register";
            // Enable this once you have account confirmation enabled for password reset functionality
            //ForgotPasswordHyperLink.NavigateUrl = "Forgot";
            //OpenAuthLogin.ReturnUrl = Request.QueryString["ReturnUrl"];
            var returnUrl = HttpUtility.UrlEncode(Request.QueryString["ReturnUrl"]);
            if (!String.IsNullOrEmpty(returnUrl))
            {
                RegisterHyperLink.NavigateUrl += "?ReturnUrl=" + returnUrl;
            }
        }

        protected void Login1_Authenticate(object sender, AuthenticateEventArgs e)
        {
            UserBO objUser = new UserBO();
            UserDTO userDTO = new UserDTO();
            userDTO.UserName = Login1.UserName;
            userDTO.Password = Login1.Password;
            e.Authenticated = objUser.checkUserAuthenticate(userDTO);
            if (e.Authenticated)
            {

                FormsAuthentication.Initialize();
                String strRole = Login1.UserName;
                FormsAuthenticationTicket fat = new FormsAuthenticationTicket(1,
                    Login1.UserName, DateTime.Now,
                    DateTime.Now.AddHours(9), false, strRole,
                    FormsAuthentication.FormsCookiePath);

                Response.Cookies.Add(new HttpCookie(FormsAuthentication.FormsCookieName,
                FormsAuthentication.Encrypt(fat)));

                Response.Redirect(FormsAuthentication.GetRedirectUrl(Login1.UserName, false));
                Response.Redirect("~/default.aspx");

            }
            objUser = null;
            userDTO = null;
        }
    }
}