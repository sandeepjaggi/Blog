﻿using Blog.Business;
using Blog.DTO;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Blog
{
    /// <summary>
    /// ManageBlog
    /// </summary>
    public partial class ManageBlog : Page
    {

        // get objects declare
        BlogDTO blogDTO = new BlogDTO();
        BlogBO blogObj = new BlogBO();
        /// <summary>
        /// Page_Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            
            if (!Page.IsPostBack)
            {
                if (ManageSession.UserName.Length > 0 && HttpContext.Current.Session["UserRole"] != null)
                {

                    this.BindBlogDetails(Convert.ToString(HttpContext.Current.Session["UserID"]));
                }
                else
                {
                    Response.Redirect("~/Account/Login.aspx");
                }
                if (ManageSession.UserName.Length > 0 && HttpContext.Current.Session["UserRole"].ToString() == "Admin"){
                    btnPublish.Visible = true;
                }
                else{
                    btnPublish.Visible = false ;
                }
            }
        }

        /// <summary>
        /// Add_Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnAdd_Click(object sender, EventArgs e)
        {
            Response.Redirect("AddBlog.aspx");
        }

        /// <summary>
        /// lnkEdit_Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void lnkEdit_Click(object sender, EventArgs e)
        {
            //Determine the RowIndex of the Row whose Button was clicked.
            int rowIndex = ((sender as Button).NamingContainer as GridViewRow).RowIndex;
            Response.Redirect("AddBlog.aspx?mode=edit&bid="+ Convert.ToInt32(gvBlogs.DataKeys[rowIndex].Values[0]));
        }

        /// <summary>
        /// lnkDelete_Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void lnkDelete_Click(object sender, EventArgs e)
        {
            //Determine the RowIndex of the Row whose Button was clicked.
            int rowIndex = ((sender as Button).NamingContainer as GridViewRow).RowIndex;
            this.blogObj.DeleteBlog(Convert.ToInt32(gvBlogs.DataKeys[rowIndex].Values[0]));
            this.BindBlogDetails(Convert.ToString(HttpContext.Current.Session["UserID"]));


        }

        /// <summary>
        /// btnPublish_Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnPublish_Click(object sender, EventArgs e)
        {
            // Return value
            int retValue=0;
                     
            try
            {
                foreach (GridViewRow row in gvBlogs.Rows)
                {
                    if (row.RowType == DataControlRowType.DataRow)
                    {
                        CheckBox chkRow = (row.Cells[0].FindControl("chkRow") as CheckBox);
                        if (chkRow.Checked)
                        {                            
                            retValue = this.blogObj.PublishBlog(Convert.ToInt32(gvBlogs.DataKeys[row.DataItemIndex].Values[0]));
                        }
                    }
                }

               // return value
                if (retValue > 0)
                {
                    this.lblResult.ForeColor = Color.Green;
                    this.lblResult.Text = "Your Article has been published succcessfully";
                }
                else
                {
                    this.lblResult.ForeColor = Color.Red;
                    this.lblResult.Text = "Fail to publish. Please try again!";
                }
            }
            catch
            {
                // TO DO:
            }
            finally
            {
                this.blogObj = null;
            }
        }
        
        /// <summary>
        /// BindBlogDetails
        /// </summary>
        protected void BindBlogDetails(string userID)
        {
            try
            {                
                this.gvBlogs.DataSource = this.blogObj.GetAllArticles(userID);
                this.gvBlogs.DataBind();                
            }
            catch
            {
                // TO DO:
            }
            finally
            {
                this.blogObj = null;
            }
        }

        /// <summary>
        /// OnRowDataBound
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void OnRowDataBound(object sender, GridViewRowEventArgs e)
        {
            
       }

    }
}