﻿using Blog.Business;
using Blog.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Blog
{
    /// <summary>
    /// _Default
    /// </summary>
    public partial class _Default : Page
    {
        // get objects declare
        BlogDTO blogDTO = new BlogDTO();
        BlogBO blogObj = new BlogBO();
        /// <summary>
        /// Page_Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                this.BindBlogList();
            }
       }

        /// <summary>
        /// 
        /// </summary>
        protected void BindBlogList()
        {
            try
            {
                this.dlBlog.DataSource = this.blogObj.GetAllArticles();
                this.dlBlog.DataBind();
            }
            catch
            {
                // TO DO:
            }
            finally
            {
                this.blogObj = null;
            }
        }
    }
}