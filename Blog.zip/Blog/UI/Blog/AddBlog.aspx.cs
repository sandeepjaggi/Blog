﻿using Blog.Business;
using Blog.DTO;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Blog
{
    /// <summary>
    /// AddBlog
    /// </summary>
    public partial class AddBlog : System.Web.UI.Page
    {
        // get objects declare       
        BlogBO blogObj = new BlogBO();
        /// <summary>
        /// Page_Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {

                if (ManageSession.UserName.Length > 0 && HttpContext.Current.Session["UserRole"] != null)
                {
                    if (Request.QueryString.Count > 0)
                    {
                        if (Request.QueryString.Get("mode") == "edit")
                        {
                            this.SetControlsValue(Convert.ToString(Request.QueryString.Get("bid")));
                        }
                    }
                }
                else
                {
                    Response.Redirect("~/Account/Login.aspx");
                }
            }
        }

        /// <summary>
        /// Submit_Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Submit_Click(object sender, EventArgs e)
        {

            if (Page.IsValid)
            {
                int retValue;
                BlogDTO blogDTO = new BlogDTO();
                try
                {
                    if (Request.QueryString.Count > 0){
                        blogDTO.BlogId = Convert.ToInt32(this.hdBlogId.Value);
                    }
                    
                    blogDTO.Title = this.txtTitle.Text;
                    blogDTO.Body = this.FreeTextBox1.Text;
                    blogDTO.AuthorBy = Convert.ToInt32(HttpContext.Current.Session["UserID"]);
                    retValue = this.blogObj.InsertUpdateBlog(blogDTO);
                    if (retValue > 0)
                    {
                        this.lblResult.ForeColor = Color.Green;
                        this.lblResult.Text = "Your Article has been save succcessfully";
                        Response.Redirect("ManageBlog.aspx");
                    }
                    else
                    {
                        this.lblResult.ForeColor = Color.Red;
                        this.lblResult.Text = "Fail to post. Please try again!";
                    }
                }
                catch (Exception ex)
                {
                    this.lblResult.ForeColor = Color.Red;
                    this.lblResult.Text = ex.Message;
                }
                finally
                {
                    blogDTO = null;
                    blogObj = null;
                }
            }
        }


        // Set DTO to Control
        /// <summary>
        /// SetControlsValue
        /// </summary>
        /// <param name="bid"></param>
        private void SetControlsValue(string bid)
        {
            BlogDTO blogDTO = new BlogDTO();
            blogDTO = this.blogObj.RetriveBlogDetails(bid);
            if (blogDTO != null)
            {
                // Set DTO to Control               
                this.txtTitle.Text = Convert.ToString(blogDTO.Title);
                this.FreeTextBox1.Text = blogDTO.Body;
                this.hdBlogId.Value = bid;

            }
            blogDTO = null;
        }
    }
}