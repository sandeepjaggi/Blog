﻿using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Security.Principal;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.AspNet.Identity;
using Blog.Business;

namespace Blog
{
    public partial class SiteMaster : MasterPage
    {

        /// <summary>
        /// Page_Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                if (ManageSession.UserName.Length > 0 && HttpContext.Current.Session["UserRole"] != null)
                {

                    this.lblUserName.Text = ManageSession.UserName.ToString().ToUpper();
                    LoggedIn.Visible = true;
                    if (HttpContext.Current.Session["UserRole"].Equals("Admin"))
                    {
                        lnkManageBlog.Visible = true;
                        lnkMangageComment.Visible = true;
                        lnkManageUser.Visible = true;
                        
                    }
                    else if (HttpContext.Current.Session["UserRole"].Equals("Standard"))
                    {
                        lnkManageBlog.Visible = true;
                        lnkMangageComment.Visible = false;
                        lnkManageUser.Visible = false;
                    }
                }
                else
                {
                    LoggedIn.Visible = false;
                    NonLogin.Visible = true;
                }
            }
        }

        /// <summary>
        /// LinkBtnLogout_Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void LinkBtnLogout_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Session.RemoveAll();
            HttpContext.Current.Session["UserName"] = null;
            HttpContext.Current.Session["UserRole"] = null;
            FormsAuthentication.SignOut();
            Response.Redirect("~/Account/login.aspx");
        }

    }

}