﻿using Blog.Business;
using Blog.DTO;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Blog
{
    /// <summary>
    /// Page_Load
    /// </summary>
    public partial class BlogDetails : System.Web.UI.Page
    {

        // get objects declare       
        BlogBO blogObj = new BlogBO();
        CommentBO commentObj = new CommentBO();
        /// <summary>
        /// Page_Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                
                    if (Request.QueryString.Count > 0)
                    {                       
                            this.BindBlogDetails(Convert.ToInt32(Request.QueryString.Get("bid")));
                            this.BindCommentDetails(Convert.ToInt32(Request.QueryString.Get("bid")));
                    
                    }
                
            }
        }

        /// <summary>
        /// BindBlogDetails
        /// </summary>
        /// <param name="userID"></param>
        private void BindBlogDetails(int blogid)
        {
            try
            {
                this.dlBlogDetails.DataSource = this.blogObj.GetSeletectedArticles(blogid);
                this.dlBlogDetails.DataBind();
            }
            catch
            {
                // TO DO:
            }
            finally
            {
                this.blogObj = null;
            }
        }

        /// <summary>
        /// BindCommentDetails
        /// </summary>
        /// <param name="blogid"></param>
        private void BindCommentDetails(int blogid)
        {
            try
            {
                this.dtComments.DataSource = this.commentObj.GetCommentsByBlogID(blogid);
                this.dtComments.DataBind();
            }
            catch
            {
                // TO DO:
            }
            finally
            {
                this.commentObj = null;
            }
        }

        /// <summary>
        /// btnPostComment_Click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnPostComment_Click(object sender, EventArgs e)
        {

            if (Page.IsValid)
            {
                int retValue;
                CommentDTO commentDTO = new CommentDTO();
                try
                {

                    commentDTO.CommentText = this.txtComments.Text;
                    commentDTO.GuestName = this.txtName.Text;
                    commentDTO.GuestEmail= this.txtEmail.Text;
                    commentDTO.BlogID = Convert.ToInt32(Request.QueryString.Get("bid"));

                    retValue = this.commentObj.InsertCommentBlog(commentDTO);
                    if (retValue > 0)
                    {
                        this.lblCommentResult.ForeColor = Color.Green;
                        this.lblCommentResult.Text = "Your comment has been posted succcessfully";
                        Response.Redirect("Default.aspx");
                    }
                    else
                    {
                        this.lblCommentResult.ForeColor = Color.Red;
                        this.lblCommentResult.Text = "Fail to post. Please try again!";
                    }
                }
                catch (Exception ex)
                {
                    this.lblCommentResult.ForeColor = Color.Red;
                    this.lblCommentResult.Text = ex.Message;
                }
                finally
                {
                    commentDTO = null;
                    commentObj = null;
                }
            }
        }

    }
}