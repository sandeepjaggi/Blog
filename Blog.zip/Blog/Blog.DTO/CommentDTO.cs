﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blog.DTO
{
    [Serializable]
    public class CommentDTO
    {
        int commentID;
        int blogID;
        string guestName;
        string guestEmail;
        string commentText;
        DateTime commentedDate;
        bool isDeleted;
        int deletedBy;

        public int CommentID
        {
            get
            {
                return commentID;
            }

            set
            {
                commentID = value;
            }
        }

        public int BlogID
        {
            get
            {
                return blogID;
            }

            set
            {
                blogID = value;
            }
        }

        public string GuestName
        {
            get
            {
                return guestName;
            }

            set
            {
                guestName = value;
            }
        }

        public string GuestEmail
        {
            get
            {
                return guestEmail;
            }

            set
            {
                guestEmail = value;
            }
        }

        public string CommentText
        {
            get
            {
                return commentText;
            }

            set
            {
                commentText = value;
            }
        }

        public DateTime CommentedDate
        {
            get
            {
                return commentedDate;
            }

            set
            {
                commentedDate = value;
            }
        }

        public bool IsDeleted
        {
            get
            {
                return isDeleted;
            }

            set
            {
                isDeleted = value;
            }
        }

        public int DeletedBy
        {
            get
            {
                return deletedBy;
            }

            set
            {
                deletedBy = value;
            }
        }
    }
}
