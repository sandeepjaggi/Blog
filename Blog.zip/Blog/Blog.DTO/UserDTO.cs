﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blog.DTO
{
    [Serializable]
    public class UserDTO
    {
        int userID;
        string userName;
        string password;
        string userType;
        string permissionLevel;
        bool isDeleted;

        /// <summary>
        /// UserID
        /// </summary>
        public int UserID
        {
            get
            {
                return userID;
            }

            set
            {
                userID = value;
            }
        }

        /// <summary>
        /// Username
        /// </summary>
        public string UserName
        {
            get
            {
                return userName;
            }

            set
            {
                userName = value;
            }
        }

        /// <summary>
        /// Usertype
        /// </summary>
        public string UserType
        {
            get
            {
                return userType;
            }

            set
            {
                userType = value;
            }
        }

        /// <summary>
        /// Permissionlevel
        /// </summary>
        public string PermissionLevel
        {
            get
            {
                return permissionLevel;
            }

            set
            {
                permissionLevel = value;
            }
        }

        /// <summary>
        /// Isdeleted
        /// </summary>
        public bool IsDeleted
        {
            get
            {
                return isDeleted;
            }

            set
            {
                isDeleted = value;
            }
        }
        /// <summary>
        /// Password
        /// </summary>
        public string Password
        {
            get
            {
                return password;
            }

            set
            {
                password = value;
            }
        }
    }
}
