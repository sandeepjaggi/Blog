﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blog.DTO
{
    [Serializable]
    
    public class BlogDTO
    {
        int blogId;
        string title;
        string body;
        bool active;
        int authorBy;
        DateTime publishedDate;

        public int BlogId
        {
            get
            {
                return blogId;
            }

            set
            {
                blogId = value;
            }
        }

        public string Title
        {
            get
            {
                return title;
            }

            set
            {
                title = value;
            }
        }

        public string Body
        {
            get
            {
                return body;
            }

            set
            {
                body = value;
            }
        }

        public bool Active
        {
            get
            {
                return active;
            }

            set
            {
                active = value;
            }
        }

        public int AuthorBy
        {
            get
            {
                return authorBy;
            }

            set
            {
                authorBy = value;
            }
        }

        public DateTime PublishedDate
        {
            get
            {
                return publishedDate;
            }

            set
            {
                publishedDate = value;
            }
        }
    }
}
