﻿using Blog.DTO;
using Blog.Utility;
using Microsoft.ApplicationBlocks.Data;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Web;

namespace Blog.Data
{
    /// <summary>
    /// UserDataAccess
    /// </summary>
    public class UserDataAccess:BaseDAL
    {

        /// <summary>
        /// string manage UserRole session
        /// </summary>
        public static String UserRole
        {
            get
            {
                if (HttpContext.Current.Session["UserRole"] != null)
                {
                    return HttpContext.Current.Session["UserRole"].ToString();
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                HttpContext.Current.Session["UserRole"] = value;
            }
        }


        /// <summary>
        /// string manage UserName session
        /// </summary>
        public static String UserName
        {
            get
            {
                if (HttpContext.Current.Session["UserName"] != null)
                {
                    return HttpContext.Current.Session["UserName"].ToString();
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                HttpContext.Current.Session["UserName"] = value;
            }
        }

        /// <summary>
        /// string manage UserID session
        /// </summary>
        public static String UserID
        {
            get
            {
                if (HttpContext.Current.Session["UserID"] != null)
                {
                    return HttpContext.Current.Session["UserID"].ToString();
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                HttpContext.Current.Session["UserID"] = value;
            }
        }

        /// <summary>
        /// RegisterBlogUser
        /// </summary>
        /// <param name="userDTO"></param>
        /// <returns></returns>
        public static int RegisterBlogUser(UserDTO userDTO)
        {
            //build params
            //Build Parameters of Blog user Register Details Information
            SqlParameter[] SqlParams = new SqlParameter[4];
            SqlParams[0] = new SqlParameter("@ReturnValue", SqlDbType.Int);
            SqlParams[0].Direction = ParameterDirection.Output;
            // params for output
            SqlParams[1] = new SqlParameter("@UserID", SqlDbType.Int, 4);
            SqlParams[1].Direction = ParameterDirection.Output;

            SqlParams[2] = new SqlParameter("@UserName", SafeConvert.Dto2Db(userDTO.UserName));
            SqlParams[3] = new SqlParameter("@Password", SafeConvert.Dto2Db(userDTO.Password));
           
            //execute query
            SqlHelper.ExecuteNonQuery(sSqlConnection, CommandType.StoredProcedure, "prRegisterBlogUser", SqlParams);
            userDTO.UserID = Convert.ToInt32(SqlParams[1].Value);
            //return values          
            return (int)SqlParams[0].Value;
        }

        /// <summary>
        /// DeleteUser
        /// </summary>
        /// <param name="userID"></param>
        public static void DeleteUser(int userID)
        {
            SqlParameter[] SqlParams = new SqlParameter[1];
            SqlParams[0] = new SqlParameter("@UserId", userID);           
            //execute query
            SqlHelper.ExecuteNonQuery(sSqlConnection, CommandType.StoredProcedure, "prDeleteUserRole", SqlParams);
        }

        /// <summary>
        /// DeleteUser
        /// </summary>
        /// <param name="Commentid"></param>
        public static void DeleteComment(int Commentid)
        {
            SqlParameter[] SqlParams = new SqlParameter[1];
            SqlParams[0] = new SqlParameter("@CommentId", Commentid);
            //execute query
            SqlHelper.ExecuteNonQuery(sSqlConnection, CommandType.StoredProcedure, "prDeletecomment", SqlParams);
        }
       

        public static void UpdateUser(int userID, string userType)
        {
            SqlParameter[] SqlParams = new SqlParameter[2];
            SqlParams[0] = new SqlParameter("@UserId", userID);
            SqlParams[1] = new SqlParameter("@UserType", userType);
            //execute query
            SqlHelper.ExecuteNonQuery(sSqlConnection, CommandType.StoredProcedure, "prUpdateUserRole", SqlParams);
        }

        /// <summary>
        /// checkUserAuthenticate
        /// </summary>
        /// <param name="userDTO"></param>
        /// <returns></returns>
        public static Boolean checkUserAuthenticate(UserDTO userDTO)
        {
            DataRow drUser;
            SQLFunctions objSql = new SQLFunctions();
            objSql.StoredProc = "UserAuthenticate";
            objSql.Type = MyCommandType.Sp;
            objSql.AddParameter("@UserName", SqlDbType.VarChar, 50, userDTO.UserName);
            objSql.AddParameter("@Password", SqlDbType.VarChar, 50, userDTO.Password);
            drUser = objSql.getRow();

            bool result = false;
            if (drUser != null)
            {
                if (drUser["UserType"].Equals("admin"))
                {
                    UserRole = "Admin";
                }
                else
                {
                    UserRole = drUser["UserType"].ToString();// Standard User
                }
                HttpContext.Current.Session["UserName"] = drUser["UserName"].ToString();
                HttpContext.Current.Session["UserRole"] = drUser["UserType"].ToString();
                HttpContext.Current.Session["UserID"] = drUser["UserID"].ToString();
                result = true;

            }

            return result;
        }

        /// <summary>
        /// GetAllUsers
        /// </summary>
        /// <returns></returns>
        public static DataTable GetAllUsers()
        {
            SQLFunctions objSql = new SQLFunctions();
            objSql.StoredProc = "prGetAllUsers";
            objSql.Type = MyCommandType.Sp;           
            return objSql.getDataTable();
        }

        /// <summary>
        /// GetAllComments
        /// </summary>
        /// <returns></returns>
        public static DataTable GetAllComments()
        {
            SQLFunctions objSql = new SQLFunctions();
            objSql.StoredProc = "prGetComments";
            objSql.Type = MyCommandType.Sp;
            return objSql.getDataTable();
        }
        

    }
}
