﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Data.SqlClient;

namespace Blog.Data
{
    /// <summary>
    /// Summary description for BaseDAC
    /// </summary>
    public abstract class BaseDAL
    {
        // connection to sales database on sql server
        public static string sSqlConnection = ConfigurationManager.ConnectionStrings["constrBlog"].ConnectionString;       
        
    }
}
