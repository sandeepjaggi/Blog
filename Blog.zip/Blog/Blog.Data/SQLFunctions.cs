﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Web;


namespace Blog.Data
{
    public enum MyCommandType
    {
        Query = 1,
        Sp = 2
    }
    /// <summary>
    /// SQLFunctions
    /// </summary>
    public class SQLFunctions : BaseDAL
    {

        private string pStoredProc;
        private MyCommandType pType;
        private DataSet ds;
        private ArrayList pParms;
        private DataTable dt;
        private SqlCommand cmd;
        private SqlDataAdapter adp;
        SqlConnection cn;

        /// <summary>
        /// SQLFunctions
        /// </summary>
        public SQLFunctions()
        {
            this.Parms = new ArrayList();
            cn = new SqlConnection(sSqlConnection);
        }

        /// <summary>
        /// getDataSet
        /// </summary>
        /// <returns></returns>
        public DataSet getDataSet()
        {
            ds = new DataSet();
            try
            {

                cmd = new SqlCommand(this.StoredProc, cn);
                if (this.Type == MyCommandType.Sp)
                    cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Clear();
                foreach (SqlParameter p in this.Parms)
                {
                    cmd.Parameters.Add(p);
                }
                adp = new SqlDataAdapter(cmd);
                adp.Fill(ds);
            }
            catch 
            {
                //TO DO:
               
            }
            finally
            {
                Parms.Clear();
                adp.Dispose();
                cmd.Connection.Close();
                cmd.Dispose();
                cn.Close();
            }
            return ds;
        }

        /// <summary>
        /// getDataTable
        /// </summary>
        /// <returns></returns>
        public DataTable getDataTable()
        {
            try
            {
                dt = new DataTable();
                cmd = new SqlCommand(this.StoredProc, cn);
                if (this.Type == MyCommandType.Sp)
                    cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Clear();
                foreach (SqlParameter p in this.Parms)
                {
                    cmd.Parameters.Add(p);
                }
                adp = new SqlDataAdapter(cmd);
                adp.Fill(dt);
            }
            catch 
            {
              
               // TO DO
            }
            finally
            {
                Parms.Clear();
                adp.Dispose();
                cmd.Connection.Close();
                cmd.Dispose();
                cn.Close();
            }
            return dt;
        }

        /// <summary>
        /// getRow
        /// </summary>
        /// <returns></returns>
        public DataRow getRow()
        {
            try
            {
                dt = new DataTable();
                cmd = new SqlCommand(this.StoredProc, cn);
                if (this.Type == MyCommandType.Sp)
                    cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Clear();
                foreach (SqlParameter p in this.Parms)
                {
                    cmd.Parameters.Add(p);
                }
                adp = new SqlDataAdapter(cmd);
                adp.Fill(dt);
            }
            catch 
            {
              //TO DO:
            }
            finally
            {
                Parms.Clear();
                adp.Dispose();
                cmd.Connection.Close();
                cmd.Dispose();
                cn.Close();
            }
            if (dt.Rows.Count > 0)
                return dt.Rows[0];
            else
                return null;
        }

        /// <summary>
        /// ExecuteNonQuery
        /// </summary>
        /// <returns></returns>
        public Int32 ExecuteNonQuery()
        {
            try
            {
                dt = new DataTable();
                cmd = new SqlCommand(this.StoredProc, cn);
                if (this.Type == MyCommandType.Sp)
                    cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Clear();
                foreach (SqlParameter p in this.Parms)
                {
                    cmd.Parameters.Add(p);
                }
                if (this.Type == MyCommandType.Sp)
                    cmd.Parameters.Add("@RETURN_VALUE", SqlDbType.Int).Direction = ParameterDirection.ReturnValue;
                cmd.Connection.Open();
                cmd.ExecuteNonQuery();
                if (this.Type == MyCommandType.Sp)
                    return Convert.ToInt32(cmd.Parameters["@RETURN_VALUE"].Value);
                else
                    return 1;
            }
            catch 
            {
               //TO DO:
            }
            finally
            {
                Parms.Clear();
                cmd.Connection.Close();
                cmd.Dispose();
                cn.Close();

            }
            return 1;
        }

        /// <summary>
        /// ExecuteScalar
        /// </summary>
        /// <returns></returns>
        public object ExecuteScalar()
        {
            object Result = new object();
            try
            {
                dt = new DataTable();
                cmd = new SqlCommand(this.StoredProc, cn);
                if (this.Type == MyCommandType.Sp)
                    cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Clear();
                foreach (SqlParameter p in this.Parms)
                {
                    cmd.Parameters.Add(p);
                }
                cmd.Connection.Open();
                Result = cmd.ExecuteScalar();
            }
            catch 
            {
               // TO DO:
            }
            finally
            {
                Parms.Clear();
                cmd.Connection.Close();
                cmd.Dispose();
                cn.Close();
            }
            return Result;
        }

        /// <summary>
        /// AddParameter
        /// </summary>
        /// <param name="Name"></param>
        /// <param name="type"></param>
        /// <param name="size"></param>
        /// <param name="val"></param>
        public void AddParameter(string Name, SqlDbType type, int size, string val)
        {
            SqlParameter p;
            if (type == SqlDbType.VarChar)
            {
                p = new SqlParameter(Name, type, size);
            }
            else
            {
                p = new SqlParameter(Name, type);
            }
            //Decimal
            if (type == SqlDbType.Decimal)
                if (p.Value != null)
                    p.Value = Convert.ToDecimal(val);
                else
                    p.Value = val;

            // Bit
            if (type == SqlDbType.Bit)
                p.Value = Convert.ToInt16(val);
            else
                p.Value = val;

            // DateTime
            if (type == SqlDbType.DateTime)
                p.Value = Convert.ToDateTime(val);
            else
                p.Value = val;

            this.Parms.Add(p);
        }

        /// <summary>
        /// StoredProc
        /// </summary>
        public string StoredProc
        {
            // TODO: Add MSSQL.StoredProc getter implementation 
            get { return pStoredProc; }
            // TODO: Add MSSQL.StoredProc setter implementation 
            set { pStoredProc = value; }
        }

        /// <summary>
        /// MyCommandType
        /// </summary>
        public MyCommandType Type
        {
            get { return pType; }
            set { pType = value; }
        }

        /// <summary>
        /// Parms
        /// </summary>
        public ArrayList Parms
        {
            // TODO: Add MSSQL.Parms getter implementation 
            get { return pParms; }
            // TODO: Add MSSQL.Parms setter implementation 
            set { pParms = value; }
        }
       

    }
}