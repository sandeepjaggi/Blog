﻿using Blog.DTO;
using Blog.Utility;
using Microsoft.ApplicationBlocks.Data;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blog.Data
{
    /// <summary>
    /// CommentDataAccess
    /// </summary>
    public class CommentDataAccess : BaseDAL
    {
        /// <summary>
        /// InsertCommentBlog
        /// </summary>
        /// <param name="commentDTO"></param>
        /// <returns></returns>
        public static int InsertCommentBlog(CommentDTO commentDTO)
        {
            //build params
            //Build Parameters of Blog Information
            SqlParameter[] SqlParams = new SqlParameter[5];
            SqlParams[0] = new SqlParameter("@ReturnValue", SqlDbType.Int);
            SqlParams[0].Direction = ParameterDirection.Output;

            SqlParams[1] = new SqlParameter("@Comment", SafeConvert.Dto2Db(commentDTO.CommentText));
            SqlParams[2] = new SqlParameter("@GuestName", SafeConvert.Dto2Db(commentDTO.GuestName));
            SqlParams[3] = new SqlParameter("@GuestEmail", SafeConvert.Dto2Db(commentDTO.GuestEmail));
            SqlParams[4] = new SqlParameter("@BlogID", SafeConvert.Dto2Db(commentDTO.BlogID));

            //execute query
            SqlHelper.ExecuteNonQuery(sSqlConnection, CommandType.StoredProcedure, "prInsertCommentBlog", SqlParams);
            //return values          
            return (int)SqlParams[0].Value;
        }

        /// <summary>
        /// GetCommentsByBlogID
        /// </summary>
        /// <param name="blogid"></param>
        /// <returns></returns>
        public static DataTable GetCommentsByBlogID(int blogid)
        {
            SQLFunctions objSql = new SQLFunctions();
            objSql.StoredProc = "prGetCommentsByBlogID";
            objSql.Type = MyCommandType.Sp;
            objSql.AddParameter("@Blogid", SqlDbType.VarChar, 50, Convert.ToString(blogid));
            return objSql.getDataTable();
        }
    }
}
