﻿using Blog.DTO;
using Blog.Utility;
using Microsoft.ApplicationBlocks.Data;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Web;


namespace Blog.Data
{
    /// <summary>
    /// BlogDataAccess
    /// </summary>
    public class BlogDataAccess : BaseDAL
    {
        /// <summary>
        /// InsertBlog
        /// </summary>
        /// <param name="blogDTO"></param>
        /// <returns></returns>
        public static int InsertUpdateBlog(BlogDTO blogDTO)
        {
            //build params
            //Build Parameters of Blog Information
            SqlParameter[] SqlParams = new SqlParameter[5];
            SqlParams[0] = new SqlParameter("@ReturnValue", SqlDbType.Int);
            SqlParams[0].Direction = ParameterDirection.Output;
           
            SqlParams[1] = new SqlParameter("@Title", SafeConvert.Dto2Db(blogDTO.Title));
            SqlParams[2] = new SqlParameter("@Body", SafeConvert.Dto2Db(blogDTO.Body));
            SqlParams[3] = new SqlParameter("@AuthorBy", SafeConvert.Dto2Db(blogDTO.AuthorBy));
            SqlParams[4] = new SqlParameter("@BlogId", SafeConvert.Dto2Db(blogDTO.BlogId));

            //execute query
            SqlHelper.ExecuteNonQuery(sSqlConnection, CommandType.StoredProcedure, "prInsertUpdateArticle", SqlParams);
            //return values          
            return (int)SqlParams[0].Value;
        }

        /// <summary>
        /// GetAllArticles for home page
        /// </summary>
        /// <returns></returns>
        public static DataTable GetAllArticles()
        {
            SQLFunctions objSql = new SQLFunctions();
            objSql.StoredProc = "prGetAllPublishedBlog";
            objSql.Type = MyCommandType.Sp;           
            return objSql.getDataTable();
        }

        /// <summary>
        /// GetSeletectedArticles
        /// </summary>
        /// <param name="blogid"></param>
        /// <returns></returns>
        public static DataTable GetSeletectedArticles(int blogid)
        {
            SQLFunctions objSql = new SQLFunctions();
            objSql.StoredProc = "prGetSeletectedArticles";
            objSql.Type = MyCommandType.Sp;
            objSql.AddParameter("@Blogid", SqlDbType.VarChar, 50, Convert.ToString(blogid));
            return objSql.getDataTable();
        }

        /// <summary>
        /// GetAllArticles
        /// </summary>
        /// <returns></returns>
        public static DataTable GetAllArticles(string userID)
        {
            SQLFunctions objSql = new SQLFunctions();
            objSql.StoredProc = "prGetAllArticles";
            objSql.Type = MyCommandType.Sp;
            objSql.AddParameter("@UserID", SqlDbType.VarChar, 50, Convert.ToString(userID));
            return objSql.getDataTable();
        }

        /// <summary>
        /// PublishBlog
        /// </summary>
        /// <param name="blogID"></param>
        /// <returns></returns>
        public static int PublishBlog(int blogID)
        {
            //build params
            //Build Parameters of Blog Information
            SqlParameter[] SqlParams = new SqlParameter[2];
            SqlParams[0] = new SqlParameter("@ReturnValue", SqlDbType.Int);
            SqlParams[0].Direction = ParameterDirection.Output;

            SqlParams[1] = new SqlParameter("@blogID", SafeConvert.Dto2Db(blogID));
          

            //execute query
            SqlHelper.ExecuteNonQuery(sSqlConnection, CommandType.StoredProcedure, "prPublishArticle", SqlParams);
            //return values          
            return (int)SqlParams[0].Value;
        }

        /// <summary>
        /// DeleteBlog
        /// </summary>
        /// <param name="bid"></param>
        public static void DeleteBlog(int bid)
        {
            //build params
            //Build Parameters of Blog Information
            SqlParameter[] SqlParams = new SqlParameter[1];
            SqlParams[0] = new SqlParameter("@blogID", SafeConvert.Dto2Db(bid));
            //execute query
            SqlHelper.ExecuteNonQuery(sSqlConnection, CommandType.StoredProcedure, "prDeleteArticle", SqlParams);
        }

        /// <summary>
        /// RetriveBlogDetails
        /// </summary>
        /// <param name="bid"></param>
        /// <returns></returns>
        public static BlogDTO RetriveBlogDetails(string bid)
        {
            // Get New DTO
            BlogDTO DTO = new BlogDTO();
            SqlParameter[] SqlParams = new SqlParameter[1];
            DataSet ds;
            DataRow dr;
            //Candidate id params
            SqlParams[0] = new SqlParameter("@blogID", SafeConvert.Dto2Db(bid));

            //execute query
            ds = SqlHelper.ExecuteDataset(sSqlConnection, CommandType.StoredProcedure, "prRetriveBlogDetails", SqlParams);
            if (ds.Tables[0].Rows.Count > 0)
            {
                dr = ds.Tables[0].Rows[0];
                DTO.Title = SafeConvert.Db2DtoString(dr["Title"]);
                DTO.Body = SafeConvert.Db2DtoString(dr["Body"]);
                //return DTO
                return DTO;
            }
            return null;
        }
    }
}
