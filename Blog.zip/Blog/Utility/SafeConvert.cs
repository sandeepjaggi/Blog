﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI.WebControls;

namespace Blog.Utility
{
    public class SafeConvert
    {
        #region Convert from DB values to DTO properties

        public static int Db2DtoInt(object obj)
        {
            if (obj == null || obj is System.DBNull) return int.MinValue;
            else return (int)obj;
        }

        public static long Db2DtoLong(object obj)
        {
            if (obj == null || obj is System.DBNull) return long.MinValue;
            else return (long)obj;
        }

        public static string Db2DtoString(object obj)
        {
            if (obj == null || obj is System.DBNull) return string.Empty;
            else return (string)obj;
        }

        public static bool Db2DtoBoolean(object obj)
        {
            if (obj == null || obj is System.DBNull) return false;
            else return (bool)obj;
        }

        public static DateTime Db2DtoDateTime(object obj)
        {
            if (obj == null || obj is System.DBNull) return DateTime.MinValue;
            else return (DateTime)obj;
        }

        public static decimal Db2DtoDecimal(object obj)
        {
            if (obj == null || obj is System.DBNull) return decimal.MinValue;
            else return (decimal)obj;
        }

        public static byte Db2DtoByte(object obj)
        {
            if (obj == null || obj is System.DBNull) return byte.MinValue;
            else return (byte)obj;
        }

        public static short Db2DtoShort(object obj)
        {
            if (obj == null || obj is System.DBNull) return short.MinValue;
            else return (short)obj;
        }

        public static float Db2DtoFloat(object obj)
        {
            if (obj == null || obj is System.DBNull) return float.MinValue;
            else
            {
                if (obj.GetType() == typeof(double))
                {
                    return Db2DtoFloatedDouble(obj);
                }
                else
                {
                    return (float)obj;
                }
            }
        }

        public static float Db2DtoFloatedDouble(object obj)
        {
            if (obj == null || obj is System.DBNull) return float.MinValue;
            else return (float)((double)obj);
        }

        public static char Db2DtoChar(object obj)
        {
            if (obj == null || obj is System.DBNull) return char.MinValue;
            else return (char)obj;
        }

        #endregion

        #region Convert from DTO properties to string (for controls)

        public static string Dto2String(string value)
        {
            return value;//for uniform coding
        }

        public static string Dto2String(int value)
        {
            if (value == int.MinValue) return string.Empty;
            else return value.ToString();
        }

        public static string Dto2String(int value, string format)
        {
            if (value == int.MinValue) return string.Empty;
            else return value.ToString(format);
        }

        public static string Dto2String(long value)
        {
            if (value == long.MinValue) return string.Empty;
            else return value.ToString();
        }

        public static string Dto2String(long value, string format)
        {
            if (value == long.MinValue) return string.Empty;
            else return value.ToString(format);
        }

        public static string Dto2String(decimal value)
        {
            if (value == decimal.MinValue) return string.Empty;
            else return value.ToString();
        }

        public static string Dto2String(decimal value, string format)
        {
            if (value == decimal.MinValue) return string.Empty;
            else return value.ToString(format);
        }

        public static string Dto2String(bool value)
        {
            if (value == false) return string.Empty;
            else return value.ToString();
        }

        public static string Dto2String(DateTime value)
        {
            if (value == DateTime.MinValue) return string.Empty;
            else return value.ToString();
        }

        public static string Dto2String(DateTime value, string format)
        {
            if (value == DateTime.MinValue) return string.Empty;
            else return value.ToString(format);
        }

        public static string Dto2String(float value)
        {
            if (value == float.MinValue) return string.Empty;
            else return value.ToString();
        }

        public static string Dto2String(short value)
        {
            if (value == short.MinValue) return string.Empty;
            else return value.ToString();
        }

        public static string Dto2String(byte value)
        {
            if (value == byte.MinValue) return string.Empty;
            else return value.ToString();
        }

        public static string Dto2String(char value)
        {
            if (value == char.MinValue) return string.Empty;
            else return value.ToString();
        }

        #endregion

        #region miscelleneous

        public static int ToIndex(int value)
        {
            if (value == int.MinValue) return -1;
            else return value;
        }

        public static string SelectedValue(int value)
        {
            if (value == int.MinValue) return string.Empty;
            else return value.ToString();
        }

        public static decimal ZeroIfNull(decimal value)
        {
            if (value == decimal.MinValue) return 0;
            else return value;
        }

        public static int ZeroIfNull(int value)
        {
            if (value == int.MinValue) return 0;
            else return value;
        }

        public static long ZeroIfNull(long value)
        {
            if (value == long.MinValue) return 0;
            else return value;
        }

        public static object DBNullIfNull(object value)
        {
            if (value == null) return System.DBNull.Value;
            else return value;
        }

        public static float ZeroIfNull(float value)
        {
            if (value == float.MinValue) return 0;
            else return value;
        }

        public static decimal NullIfZero(decimal value)
        {
            if (value == 0) return decimal.MinValue;
            else return value;
        }

        public static byte NullIfZero(byte value)
        {
            if (value == 0) return byte.MinValue;
            else return value;
        }

        public static short NullIfZero(short value)
        {
            if (value == 0) return short.MinValue;
            else return value;
        }

        public static int NullIfZero(int value)
        {
            if (value == 0) return int.MinValue;
            else return value;
        }

        public static float NullIfZero(float value)
        {
            if (value == 0) return float.MinValue;
            else return value;
        }
        public static long NullIfZero(long value)
        {
            if (value == 0) return long.MinValue;
            else return value;
        }
        public static void SetSelectedValue(ListControl listControl, int value)
        {
            SafeConvert.SetSelectedValue(listControl, SafeConvert.SelectedValue(value));
        }

        public static void SetSelectedValue(ListControl listControl, string value)
        {
            try { listControl.SelectedValue = value; }
            catch { }
        }

        #endregion

        #region Convert from DTO properties to object (for DB values)

        public static object Dto2Db(string value)
        {
            if (value == string.Empty) return null;
            else return value;
        }

        public static object Dto2Db(int value)
        {
            if (value == int.MinValue) return null;
            else return value;
        }



        public static object Dto2Db(long value)
        {
            if (value == long.MinValue) return null;
            else return value;
        }

        public static object Dto2Db(decimal value)
        {
            if (value == decimal.MinValue) return null;
            else return value;
        }

        public static object Dto2Db(DateTime value)
        {
            if (value == DateTime.MinValue) return System.DBNull.Value;
            else return value;
        }

        public static object Dto2Db(short value)
        {
            if (value == short.MinValue) return null;
            else return value;
        }

        public static object Dto2Db(byte value)
        {
            if (value == byte.MinValue) return null;
            else return value;
        }

        public static object Dto2Db(char value)
        {
            if (value == char.MinValue) return null;
            else return value;
        }

        public static object Dto2Db(bool value)
        {
            return value;//for uniform code
        }

        public static object Dto2Db(float value)
        {
            if (value == float.MinValue) return null;
            else return value;
        }

        #endregion

        #region Check for datatype

        public static bool isInt(string value)
        {
            int result;
            return int.TryParse(value, out result);
        }

        public static bool IsNumeric(object Expression)
        {
            bool isNum;
            double retNum;
            isNum = Double.TryParse(Convert.ToString(Expression), System.Globalization.NumberStyles.Any, System.Globalization.NumberFormatInfo.InvariantInfo, out retNum);
            return isNum;
        }

        public static bool isLong(string value)
        {
            long result;
            return long.TryParse(value, out result);
        }

        public static bool isBoolean(string value)
        {
            bool result;
            return bool.TryParse(value, out result);
        }

        public static bool isDateTime(string value)
        {
            DateTime result;
            return DateTime.TryParse(value, out result);
        }

        public static bool isDecimal(string value)
        {
            decimal result;
            return decimal.TryParse(value, out result);
        }

        public static bool isFloat(string value)
        {
            float result;
            return float.TryParse(value, out result);
        }

        public static bool isShort(string value)
        {
            short result;
            return short.TryParse(value, out result);
        }

        public static bool isByte(string value)
        {
            byte result;
            return byte.TryParse(value, out result);
        }

        public static bool isChar(string value)
        {
            char result;
            return char.TryParse(value, out result);
        }

        #endregion

        #region String to type (from controls to DTO properties)

        public static string Str2DtoString(string value)
        {
            return value.Trim();
        }

        public static int Str2DtoInt(string value)
        {
            if (SafeConvert.isInt(value)) return int.Parse(value);
            else return int.MinValue;
        }

        public static long Str2DtoLong(string value)
        {
            if (SafeConvert.isLong(value)) return long.Parse(value);
            else return long.MinValue;
        }

        public static DateTime Str2DtoDateTime(string value)
        {
            if (SafeConvert.isDateTime(value)) return DateTime.Parse(value);
            else return DateTime.MinValue;
        }

        public static short Str2DtoShort(string value)
        {
            if (SafeConvert.isShort(value)) return short.Parse(value);
            else return short.MinValue;
        }

        public static byte Str2DtoBtye(string value)
        {
            if (SafeConvert.isByte(value)) return byte.Parse(value);
            else return byte.MinValue;
        }

        public static char Str2DtoChar(string value)
        {
            if (SafeConvert.isChar(value)) return char.Parse(value);
            else return char.MinValue;
        }

        #endregion
    }
}
